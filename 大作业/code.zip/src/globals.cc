#include"globals.h"
uint32_t my_priority[LLC_SET][LLC_WAY]={0};