#include"cache.h"

extern uint32_t my_priority[LLC_SET][LLC_WAY];