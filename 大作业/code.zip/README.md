# ChampSim
ChampSim is a trace-based simulator for a microarchitecture study

# How To
Please read the handout in detail to know more.

# How to download data traces?
You can download two application traces via [Baidu Cloud](https://pan.baidu.com/s/1HGR2XD61YRDWr4a6fh8Ugw?pwd=nkcs).

refer:https://gitlab.ethz.ch/rahbera/champsim.git
