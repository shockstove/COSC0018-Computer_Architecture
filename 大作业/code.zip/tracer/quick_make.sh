make PIN_ROOT=/home/grads/c/cienlux/cienlux/task/pin-3.0-76991-gcc-linux obj-intel64/champsim_tracer.so
